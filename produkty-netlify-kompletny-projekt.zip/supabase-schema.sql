create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  description text not null default '',
  price numeric(10,2) not null check (price >= 0),
  image_url text,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;

-- Všetky čítania a zmeny idú cez Netlify Functions, ktoré používajú
-- tajný kľúč iba na serveri. Verejní návštevníci nemajú priamy prístup.
revoke all on table public.products from anon, authenticated;
grant all on table public.products to service_role;
