const headers = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff"
};
function json(status, body) {
  return new Response(JSON.stringify(body), { status, headers });
}
export default async (req) => {
  if (req.method !== "GET") return json(405, { error: "Method not allowed." });
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return json(500, { error: "Databáza nie je nastavená. Skontroluj premenné v Netlify." });
  try {
    const response = await fetch(`${url.replace(/\/$/, "")}/rest/v1/products?select=id,name,description,price,image_url,created_at&order=created_at.desc`, {
      headers: { apikey: key, Authorization: `Bearer ${key}` }
    });
    if (!response.ok) return json(502, { error: "Databáza neodpovedala správne." });
    return json(200, { products: await response.json() });
  } catch {
    return json(502, { error: "Nepodarilo sa spojiť s databázou." });
  }
};
