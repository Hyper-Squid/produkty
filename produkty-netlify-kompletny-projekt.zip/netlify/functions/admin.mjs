import { createHmac, timingSafeEqual, randomBytes } from "node:crypto";

const COOKIE = "produkty_admin";
const SESSION_SECONDS = 8 * 60 * 60;
const commonHeaders = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "Vary": "Cookie"
};
function json(status, body, extra = {}) {
  return new Response(JSON.stringify(body), { status, headers: { ...commonHeaders, ...extra } });
}
function secret(name) { return process.env[name] || ""; }
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}
function sign(payload) {
  return createHmac("sha256", secret("ADMIN_SESSION_SECRET")).update(payload).digest("base64url");
}
function makeToken() {
  const payload = Buffer.from(JSON.stringify({ exp: Math.floor(Date.now() / 1000) + SESSION_SECONDS, nonce: randomBytes(12).toString("hex") })).toString("base64url");
  return `${payload}.${sign(payload)}`;
}
function validToken(token) {
  if (!token || !secret("ADMIN_SESSION_SECRET")) return false;
  const parts = token.split(".");
  if (parts.length !== 2 || !safeEqual(parts[1], sign(parts[0]))) return false;
  try {
    const data = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"));
    return Number.isInteger(data.exp) && data.exp > Math.floor(Date.now() / 1000);
  } catch { return false; }
}
function getCookie(req, name) {
  const raw = req.headers.get("cookie") || "";
  for (const part of raw.split(";")) {
    const idx = part.indexOf("=");
    if (idx >= 0 && part.slice(0, idx).trim() === name) return part.slice(idx + 1).trim();
  }
  return "";
}
function cookie(value, maxAge) {
  return `${COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}
function sameOrigin(req) {
  const origin = req.headers.get("origin");
  if (!origin) return true;
  try {
    const o = new URL(origin);
    const h = new URL(req.url);
    return o.host === h.host && o.protocol === h.protocol;
  } catch { return false; }
}
async function supabase(path, method = "GET", body) {
  const base = secret("SUPABASE_URL").replace(/\/$/, "");
  const key = secret("SUPABASE_SERVICE_ROLE_KEY");
  if (!base || !key) throw new Error("Databáza nie je nastavená.");
  const response = await fetch(`${base}/rest/v1/${path}`, {
    method,
    headers: {
      apikey: key, Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: method === "POST" ? "return=representation" : "return=minimal"
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) })
  });
  if (!response.ok) {
    const errorText = await response.text();
    console.error("Supabase request failed:", response.status, errorText.slice(0, 300));
    throw new Error("Databázová operácia zlyhala. Skontroluj tabuľku a jej nastavenie.");
  }
  if (response.status === 204 || method === "DELETE") return null;
  return response.json();
}
export default async (req) => {
  if (req.method !== "POST") return json(405, { error: "Method not allowed." }, { Allow: "POST" });
  if (!sameOrigin(req)) return json(403, { error: "Neplatný pôvod požiadavky." });
  if (!secret("ADMIN_PASSWORD") || !secret("ADMIN_SESSION_SECRET") || !secret("SUPABASE_URL") || !secret("SUPABASE_SERVICE_ROLE_KEY")) {
    return json(500, { error: "Chýbajú nastavenia servera v Netlify." });
  }
  let data;
  try { data = await req.json(); } catch { return json(400, { error: "Neplatné JSON dáta." }); }
  const action = data?.action;
  if (action === "login") {
    if (typeof data.password !== "string" || !safeEqual(data.password, secret("ADMIN_PASSWORD"))) {
      return json(401, { error: "Nesprávne heslo." });
    }
    return json(200, { ok: true }, { "Set-Cookie": cookie(makeToken(), SESSION_SECONDS) });
  }
  if (action === "logout") {
    return json(200, { ok: true }, { "Set-Cookie": cookie("", 0) });
  }
  if (!validToken(getCookie(req, COOKIE))) return json(401, { error: "Prihlásenie vypršalo. Prihlás sa znova." });
  try {
    if (action === "add") {
      const p = data.product;
      if (!p || typeof p.name !== "string" || !p.name.trim() || p.name.trim().length > 100) return json(400, { error: "Názov produktu je povinný (max. 100 znakov)." });
      const price = Number(p.price);
      if (!Number.isFinite(price) || price < 0 || price > 1000000) return json(400, { error: "Cena musí byť číslo od 0 do 1 000 000 €." });
      const description = typeof p.description === "string" ? p.description.trim() : "";
      if (description.length > 1000) return json(400, { error: "Popis môže mať najviac 1000 znakov." });
      let imageUrl = typeof p.image_url === "string" ? p.image_url.trim() : "";
      if (imageUrl) {
        try {
          const u = new URL(imageUrl);
          if (!["https:", "http:"].includes(u.protocol)) throw new Error();
        } catch { return json(400, { error: "Odkaz na obrázok musí byť platná HTTP alebo HTTPS adresa." }); }
      }
      const created = await supabase("products", "POST", { name: p.name.trim(), description, price: Math.round(price * 100) / 100, image_url: imageUrl || null });
      return json(201, { ok: true, product: created?.[0] || null });
    }
    if (action === "delete") {
      if (typeof data.id !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(data.id)) return json(400, { error: "Neplatné ID produktu." });
      await supabase(`products?id=eq.${encodeURIComponent(data.id)}`, "DELETE");
      return json(200, { ok: true });
    }
    return json(400, { error: "Neznáma operácia." });
  } catch (error) {
    console.error("Admin function error:", error);
    return json(500, { error: error.message || "Interná chyba servera." });
  }
};
