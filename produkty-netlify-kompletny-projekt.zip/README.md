# Produkty – Netlify + Supabase

## Súbory
- `public/` – verejný obchod a admin rozhranie
- `netlify/functions/products.mjs` – verejné čítanie produktov
- `netlify/functions/admin.mjs` – prihlásenie, pridávanie a mazanie
- `supabase-schema.sql` – databázová tabuľka a oprávnenia
- `netlify.toml` – nastavenie nasadenia

## Nasadenie
1. Vytvor projekt na https://supabase.com.
2. V Supabase otvor SQL Editor, vlož celý obsah `supabase-schema.sql` a spusti ho.
3. V Supabase Project Settings → API (alebo API Keys) skopíruj Project URL a tajný `service_role`/secret kľúč. Kľúč nikdy nedávaj do `public/` ani do GitHubu.
4. Nahraj obsah tohto projektu do koreňového priečinka GitHub repozitára. Zachovaj štruktúru priečinkov.
5. Na https://app.netlify.com pridaj nový web cez Import an existing project a vyber GitHub repozitár. Build command nechaj prázdny; publish directory nastav na `public`. `netlify.toml` určuje functions directory.
6. V Netlify → Site configuration / Project configuration → Environment variables pridaj:
   - `SUPABASE_URL` = Project URL zo Supabase
   - `SUPABASE_SERVICE_ROLE_KEY` = tajný service_role/secret kľúč zo Supabase
   - `ADMIN_PASSWORD` = vlastné dlhé, jedinečné administrátorské heslo
   - `ADMIN_SESSION_SECRET` = náhodný tajný reťazec aspoň 32 bajtov
7. Ulož premenné a spusti nový deploy (Deploys → Trigger deploy → Deploy site).
8. Otvor `https://tvoja-stranka.netlify.app/` a admin panel na `https://tvoja-stranka.netlify.app/admin.html`.

## Vygenerovanie ADMIN_SESSION_SECRET
V termináli s Node.js môžeš spustiť:
`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
Skopíruj výsledok do Netlify ako hodnotu `ADMIN_SESSION_SECRET`. Nepouži túto hodnotu ako heslo.

## Dôležité
- Všetky tajné premenné nastavuj v Netlify, nie v súboroch.
- Po zmene environment variables urob nový deploy.
- Admin cookie je HttpOnly, Secure, SameSite=Strict a platí 8 hodín.
- Tento projekt spravuje katalóg produktov; tlačidlo kúpy ani platby zatiaľ nie sú implementované.
