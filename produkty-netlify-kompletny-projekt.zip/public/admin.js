const loginPanel = document.querySelector("#login-panel");
const dashboard = document.querySelector("#dashboard");
const loginForm = document.querySelector("#login-form");
const productForm = document.querySelector("#product-form");
const loginNotice = document.querySelector("#login-notice");
const notice = document.querySelector("#notice");
const adminProducts = document.querySelector("#admin-products");
const logoutBtn = document.querySelector("#logout");

function showNotice(el, message, ok = false) {
  el.textContent = message; el.className = "notice show " + (ok ? "ok" : "bad");
}
async function api(action, data = {}) {
  const res = await fetch("/.netlify/functions/admin", {
    method: "POST", headers: { "Content-Type": "application/json" },
    credentials: "same-origin", body: JSON.stringify({ action, ...data })
  });
  const result = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(result.error || "Požiadavka sa nepodarila.");
  return result;
}
function showDashboard() {
  loginPanel.classList.add("hidden"); dashboard.classList.remove("hidden"); logoutBtn.classList.remove("hidden");
}
function showLogin() {
  loginPanel.classList.remove("hidden"); dashboard.classList.add("hidden"); logoutBtn.classList.add("hidden");
}
async function refreshProducts() {
  adminProducts.replaceChildren(Object.assign(document.createElement("p"), { className: "status", textContent: "Načítavam produkty…" }));
  try {
    const res = await fetch("/.netlify/functions/products");
    if (!res.ok) throw new Error("Nepodarilo sa načítať produkty.");
    const data = await res.json(), products = data.products || [];
    document.querySelector("#admin-count").textContent = `(${products.length})`;
    adminProducts.replaceChildren();
    if (!products.length) {
      adminProducts.append(Object.assign(document.createElement("p"), { className: "status", textContent: "Zatiaľ nie sú pridané žiadne produkty." }));
      return;
    }
    products.forEach(p => {
      const row = document.createElement("div"); row.className = "admin-product";
      const img = document.createElement("img"); img.className = "admin-thumb"; img.alt = ""; img.src = p.image_url || ""; img.onerror = () => { img.removeAttribute("src"); };
      const main = document.createElement("div"); main.className = "admin-product-main";
      const name = document.createElement("strong"); name.textContent = p.name;
      const price = document.createElement("span"); price.textContent = new Intl.NumberFormat("sk-SK", { style: "currency", currency: "EUR" }).format(Number(p.price));
      main.append(name, price);
      const del = document.createElement("button"); del.className = "button-danger"; del.type = "button"; del.textContent = "Odstrániť";
      del.addEventListener("click", async () => {
        if (!confirm(`Naozaj chceš odstrániť produkt „${p.name}“?`)) return;
        del.disabled = true;
        try { await api("delete", { id: p.id }); showNotice(notice, "Produkt bol odstránený.", true); await refreshProducts(); }
        catch (e) { showNotice(notice, e.message); del.disabled = false; }
      });
      row.append(img, main, del); adminProducts.append(row);
    });
  } catch (e) { adminProducts.replaceChildren(Object.assign(document.createElement("p"), { className: "status error", textContent: e.message })); }
}
loginForm.addEventListener("submit", async e => {
  e.preventDefault();
  const button = loginForm.querySelector("button"); button.disabled = true;
  try { await api("login", { password: document.querySelector("#password").value }); showDashboard(); showNotice(notice, "Prihlásenie bolo úspešné.", true); await refreshProducts(); }
  catch (err) { showNotice(loginNotice, err.message); }
  finally { button.disabled = false; }
});
productForm.addEventListener("submit", async e => {
  e.preventDefault();
  const button = productForm.querySelector("button"); button.disabled = true;
  const product = {
    name: document.querySelector("#name").value.trim(),
    price: Number(document.querySelector("#price").value),
    description: document.querySelector("#description").value.trim(),
    image_url: document.querySelector("#image_url").value.trim()
  };
  try {
    await api("add", { product });
    productForm.reset(); showNotice(notice, "Produkt bol pridaný do databázy.", true); await refreshProducts();
  } catch (err) { showNotice(notice, err.message); }
  finally { button.disabled = false; }
});
logoutBtn.addEventListener("click", async () => {
  try { await api("logout"); } catch {}
  showLogin(); document.querySelector("#password").value = "";
});
