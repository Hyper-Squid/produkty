const productsEl = document.querySelector("#products");
const statusEl = document.querySelector("#status");
const countEl = document.querySelector("#product-count");
document.querySelector("#year").textContent = new Date().getFullYear();

function safeImageUrl(value) {
  try {
    const u = new URL(value);
    return (u.protocol === "https:" || u.protocol === "http:") ? u.href : "";
  } catch { return ""; }
}
function euro(value) {
  return new Intl.NumberFormat("sk-SK", { style: "currency", currency: "EUR" }).format(Number(value));
}
function renderProduct(p) {
  const card = document.createElement("article");
  card.className = "product-card";
  const imageBox = document.createElement("div");
  imageBox.className = "product-image";
  const imageUrl = safeImageUrl(p.image_url || "");
  if (imageUrl) {
    const img = document.createElement("img");
    img.src = imageUrl; img.alt = p.name || "Produkt"; img.loading = "lazy";
    img.onerror = () => { imageBox.replaceChildren(); const ph = document.createElement("span"); ph.className = "image-placeholder"; ph.textContent = "P."; imageBox.append(ph); };
    imageBox.append(img);
  } else {
    const ph = document.createElement("span"); ph.className = "image-placeholder"; ph.textContent = "P."; imageBox.append(ph);
  }
  const info = document.createElement("div"); info.className = "product-info";
  const meta = document.createElement("div"); meta.className = "product-meta";
  const tag = document.createElement("span"); tag.className = "product-tag"; tag.textContent = "V PONUKE";
  const price = document.createElement("span"); price.className = "price"; price.textContent = euro(p.price);
  meta.append(tag, price);
  const title = document.createElement("h3"); title.textContent = p.name;
  const desc = document.createElement("p"); desc.textContent = p.description || "Kvalitný produkt z našej ponuky.";
  info.append(meta, title, desc); card.append(imageBox, info); return card;
}
async function loadProducts() {
  try {
    const response = await fetch("/.netlify/functions/products");
    if (!response.ok) throw new Error("Produkty sa nepodarilo načítať.");
    const data = await response.json();
    const products = Array.isArray(data.products) ? data.products : [];
    countEl.textContent = String(products.length).padStart(2, "0");
    productsEl.replaceChildren();
    if (!products.length) {
      statusEl.textContent = "Zatiaľ tu nie sú žiadne produkty. Pridaj ich cez admin panel.";
      productsEl.append(Object.assign(document.createElement("div"), { className: "empty", textContent: "Ponuka sa práve pripravuje." }));
    } else {
      statusEl.textContent = "";
      products.forEach(p => productsEl.append(renderProduct(p)));
    }
  } catch (err) {
    statusEl.textContent = err.message || "Nastala chyba pri načítaní.";
    statusEl.classList.add("error");
  }
}
loadProducts();
